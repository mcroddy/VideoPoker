﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeckController : MonoBehaviour {
    //TODO make cards

    public Sprite[] spriteList;
    private GameController gameController;
    public int cardNumber;
    public bool held;
    public Canvas canvas;
    public GameObject heldTextObj;
    // initialization
    void Start ()
    {
        // set up gamecontroller
       
        GameObject gameController = GameObject.FindWithTag("GameController");
        this.gameController = gameController.GetComponent<GameController>();
        BeginGame();
    }

   
    public void BeginGame()
    {
        RandomizeCard();
        held = false;
    }
	
	// Update is called once per frame
	void Update ()
    {
        
    }

    public void RandomizeCard()
    {

        int randomInt = (Random.Range(0, spriteList.Length));
        cardNumber = randomInt + 1;
        this.GetComponent<SpriteRenderer>().sprite = Instantiate(spriteList[randomInt]) as Sprite;
        
    }

    public void setHeld()
    {
        gameController.heldText.enabled = true;
        held = true;
        gameController.heldText.transform.position = new Vector3(0,0, 0);
 
        
       
    }


    public void ResetHand()
    {
       
        held = false;
        gameController.heldText.enabled = held;
   
    }

    private void OnMouseDown()
    {
        
        if (Input.GetMouseButtonDown(0) && !held)
        {
            
            setHeld();
        }
    }
}
