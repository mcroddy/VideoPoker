﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SubmitController : MonoBehaviour
{
  
    private GameController gameController;
    private DeckController deckController;
    private HitController hitController;
    public GameObject card;
    // initialization
    void Start()
    {
        // set up gamecontroller
        GameObject gameController = GameObject.FindWithTag("GameController");
        this.gameController = gameController.GetComponent<GameController>();
        // set up deckController
        GameObject deckController = GameObject.FindWithTag("DeckController");
        this.deckController = deckController.GetComponent<DeckController>();
        GameObject hitController = GameObject.FindWithTag("HitController");
        this.hitController = hitController.GetComponent<HitController>();

    }

    // Update is called once per frame
    void Update()
    {

    }

  
  
    public void Hit()
    {
        if (!hitController.isHit)
        {
            GameObject[] cardArray = GameObject.FindGameObjectsWithTag("DeckController");
            int counter = 0;
            foreach (GameObject current in cardArray)
            {
                
              //  if (!current.GetComponent<DeckController>().held)
              //      GameObject.Destroy(current);
              //  Instantiate(card, new Vector3(counter, -1, 0), Quaternion.identity);
             //   counter += 1;
            }

            for (int i = 0; i < 5; i++)
            {
                if (!cardArray[i].GetComponent<DeckController>().held)
                {
                    GameObject.Destroy(cardArray[i]);
                    Instantiate(card, new Vector3(i, -1, 0), Quaternion.identity);
                }

            }
        }

        hitController.isHit = true;
       
    }


    private void OnMouseDown()
    {
        if (Input.GetMouseButtonDown(0))
        {
          


            GameObject[] cardArray = GameObject.FindGameObjectsWithTag("DeckController");
            GameObject[] textArray = GameObject.FindGameObjectsWithTag("Respawn");


            //calculate the payout
            int payout = gameController.CashOut(cardArray);
            gameController.winText.enabled = true;
            gameController.winText.text += " +" + payout;

            gameController.AddMoney(payout);


            foreach (GameObject current in cardArray)
            {

                GameObject.Destroy(current);
            }
            foreach (GameObject current in textArray)
            {

                //GameObject.Destroy(current);
            }
            //  Debug.Log(cardArray[0].GetComponent<DeckController>().cardNumber);
            // Debug.Log(cardArray[1].GetComponent<DeckController>().cardNumber);
            // Debug.Log(cardArray[2].GetComponent<DeckController>().cardNumber);
            // Debug.Log(cardArray[3].GetComponent<DeckController>().cardNumber);
            // Debug.Log(cardArray[4].GetComponent<DeckController>().cardNumber);


            hitController.isHit = false;
            gameController.SpawnCards();

            deckController.ResetHand();
            Debug.Log("Next round started!");
        }
    }
}
