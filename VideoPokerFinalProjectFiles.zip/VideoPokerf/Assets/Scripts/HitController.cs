﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitController : MonoBehaviour {

    public bool isHit;
    private DeckController deckController;
    private GameController gameController;
    private SubmitController submitController;
    // initialization
    void Start()
    {
     
        isHit = false;
        GameObject gameController = GameObject.FindWithTag("GameController");
        this.gameController = gameController.GetComponent<GameController>();

        GameObject submitController = GameObject.FindWithTag("SubmitController");
        this.submitController = submitController.GetComponent<SubmitController>();
    }

    // Update is called once per frame
    void Update()
    {

    }


 

    private void OnMouseDown()
    {
      
        if (Input.GetMouseButtonDown(0))
        {

            

            submitController.Hit();
            
            Debug.Log("DEBUG: HIT");
        }
    }
}
