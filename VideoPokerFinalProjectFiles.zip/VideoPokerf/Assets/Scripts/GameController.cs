﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour {

    //holding the player's money between rounds
    private int money;
    //UI component for player money 
    public Text moneyText;
    public Text heldText;
    public Text winText;
    public GameObject card;
    public GameObject heldTextObject;
    public Canvas canvas;
  


    // initilization 
    void Start ()
    {

        money = PlayerPrefs.GetInt("money", 0);
       
        //use later when you need to update the total money- persists 
        //PlayerPrefs.SetInt("money", money);

        BeginGame();

    }

    void BeginGame()
    {

        money = 100;

        // Set up GUI text
        moneyText.text = "Money: " + money;
        heldText.text = "HELD";
        winText.text = "";
        winText.transform.position = new Vector3(-2,1, 0);
        //no cards are being held yet
        heldText.enabled = false;
        //win not displayed yet
        winText.enabled = false;
        UpdateText();

        SpawnCards();

    }

    public void SpawnCards()
    {

  
            for (int i = 0; i < 5; i++)
            {
      
          
                Instantiate(card, new Vector3(i, -1, 0), Quaternion.identity);
           
            }
        
    }

    void UpdateText()
    {
        // refresh text
        moneyText.text = "Money: " + money;
        heldText.text = "HELD";
        
    }

    // Update is called once per frame
    void Update ()
    {
        // hit escape to quit
        if (Input.GetKey("escape")) Application.Quit();
        UpdateText();
    }

    public void AddMoney(int munny)
    {
        money += munny;
    }

    public int CashOut(GameObject[] array)
    {
        winText.text = "";
        bool isFlush = false;
        bool isRoyalFlush = false;
        bool isStraight = true;
        bool isConsecutive = false;

        
        List<int> cardList = new List<int>();
        List<int> divList = new List<int>();
        foreach (GameObject card in array)
        {
            cardList.Add(card.GetComponent<DeckController>().cardNumber);
            Debug.Log(card.GetComponent<DeckController>().cardNumber);
        }
       
        //sorted card list by value
        cardList.Sort();

        for (int i = 0; i < 5; i++)
        {
            Debug.Log("card: " + cardList[i]);
           
            if(cardList[i] > 13)
            { divList.Add(cardList[i] % 13);
            }
            else
                divList.Add(cardList[i]);

            //Debug.Log("div: " + divList[i]);

        }
        divList.Sort();
        //is it a straight?
        string divString = string.Join(",", divList.Select(x => x.ToString()).ToArray());
        Debug.Log("The cards: " + divString);
        string[] divStringArray = divString.Split(new char[]{','});
        List<int> countList = new List<int>();

        //checking for pairs, three or four of a kind
        for (int i = 0; i < 5; i++)
        {
            string checkString = (divList[i]).ToString();

            var matchQuery = from word in divStringArray
                             where word == checkString
                             select word;

            // Count the matches, which executes the query.  
            int wordCount = matchQuery.Count();

           // int matches = Regex.Matches(divString, checkString).Cast<Match>().Count();
            countList.Add(wordCount);
            //Debug.Log("matchlist: " + matches);
            Debug.Log("QUERY: " + wordCount);
        }
        
        if(countList.Contains(4))
        { //four of a kind
            Debug.Log("FOUR OF A KIND");
            winText.text += "Four of a kind";
            return 25;
        }
        else if(countList.Contains(3))
        {
            if(countList.Contains(3) && countList.Contains(2))
            {
                //full house
                Debug.Log("FULL HOUSE");
                winText.text += "Full House";
                return 9;
            }
            Debug.Log("THREE OF A KIND");
            //three of a kind
            winText.text = "3 of a Kind";
            return 3;
        }
        else if(countList.Contains(2))
        {
            //Check for TWO PAIRS
           int countPair = 0;
            for(int i =0; i < 5; i++)
            {
                if (countList[i] == 2)
                    countPair += 1;
            }
            if (countPair == 4)
            {
                Debug.Log("TWO PAIRS");
                winText.text += "Two Pairs";
                return 2;
            }


        }

        for (int i = 0; i < 4; i++)
        {
            if (divList[i] + 1 != divList[i + 1])
                isStraight = false;
                
        }

        //check if the cards are all in the same suit

        if (cardList[4] < 13)
        {
            //all clubs
            isFlush = true;
        }
       else if (cardList[0] > 13 && cardList[4] < 26 )
        {
            //diamonds
            isFlush = true;
        }
        else if(cardList[0] > 26 && cardList[4] < 39)
        {
            //hearts
            isFlush = true;
        }
        else if(cardList[0] > 39)
        {
            //spades
            isFlush = true;
        }


        //check royal flush
        if(isFlush)
        {
            if(divList.Contains(1) && divList.Contains(13) && divList.Contains(12) && divList.Contains(11) && divList.Contains(10))
            {
                isRoyalFlush = true;
                Debug.Log("ROYAL FLUSH");
                winText.text += "Royal Flush";
                return 800;
            }
            else if(isStraight)
            {
                //straight flush
                Debug.Log("STRAIGHT FLUSH");
                winText.text += "Straight Flush";
                return 50;
            }
            
        }
        else if (isStraight)
        {
            Debug.Log("STRAIGHT");
            winText.text += "Straight";
            return 4;
        }
        
        //jacks or better, last call for a point
        if(divList.Contains(11) || divList.Contains(12) || divList.Contains(13))
        {
            if (countList.Contains(2))
            {
                //Check for TWO PAIRS
                int countPair = 0;
                for (int i = 0; i < 5; i++)
                {
                    if (countList[i] == 2)
                        countPair += 1;
                }
                if (countPair == 4)
                {
                    Debug.Log("TWO PAIRS");
                    winText.text += "Two Pairs";
                    return 2;
                }


            }
            Debug.Log("JACK/BETTER");
            winText.text += "Jack or better";
            return 1;
        }
        //no points...

      

        return 0;

    }



}
